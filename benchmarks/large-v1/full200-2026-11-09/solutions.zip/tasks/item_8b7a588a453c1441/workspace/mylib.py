def choose():
 return 76
