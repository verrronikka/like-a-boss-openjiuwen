import unittest
import mylib as m
class Tests(unittest.TestCase):
 def test_contract(self):
  v=m.transform([79,3])
  self.assertIs(type(v),list)
  self.assertEqual(v,[85, 9])
  self.assertEqual(v,[85, 9])
if __name__=='__main__': unittest.main()
