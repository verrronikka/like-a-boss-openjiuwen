def transform(xs):
    return [x + 6 if isinstance(x, int) else x for x in xs]
