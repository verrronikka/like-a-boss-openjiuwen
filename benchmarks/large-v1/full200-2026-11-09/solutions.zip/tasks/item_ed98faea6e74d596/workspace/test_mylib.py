import unittest
import mylib as m
class Tests(unittest.TestCase):
 def test_contract(self):
  v=m.unique([48,4,48,5,4])
  self.assertIs(type(v),list)
  self.assertEqual(v,[48, 4, 5])
  self.assertEqual(v,[48, 4, 5, 999])
if __name__=='__main__': unittest.main()
