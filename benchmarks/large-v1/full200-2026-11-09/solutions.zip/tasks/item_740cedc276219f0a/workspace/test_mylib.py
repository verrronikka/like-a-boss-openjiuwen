import unittest
import mylib as m
class Tests(unittest.TestCase):
 def test_contract(self):
  v=m.unique([52,2,52,9,2])
  self.assertIs(type(v),list)
  self.assertEqual(v,[52, 2, 9])
  self.assertEqual(v,[52, 2, 9])
if __name__=='__main__': unittest.main()
