import unittest
import mylib as m
class Tests(unittest.TestCase):
 def test_contract(self):
  v=m.sorted_copy([75,4,7])
  self.assertIs(type(v),list)
  self.assertEqual(v,[4, 7, 75])
  self.assertEqual(v,[4, 7, 75, 999])
if __name__=='__main__': unittest.main()
