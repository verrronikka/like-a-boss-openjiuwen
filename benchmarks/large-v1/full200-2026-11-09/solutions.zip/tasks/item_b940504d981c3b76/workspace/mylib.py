def sorted_copy(xs):
 return xs
