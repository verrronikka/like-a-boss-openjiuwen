import unittest
import mylib as m
class Tests(unittest.TestCase):
 def test_contract(self):
  v=m.sorted_copy([38,3,5])
  self.assertIs(type(v),list)
  self.assertEqual(v,[3, 5, 38])
  self.assertEqual(v,[3, 5, 38])
  xs=[38,3,5]
  m.sorted_copy(xs)
  self.assertEqual(xs,[38,3,5])
if __name__=='__main__': unittest.main()
