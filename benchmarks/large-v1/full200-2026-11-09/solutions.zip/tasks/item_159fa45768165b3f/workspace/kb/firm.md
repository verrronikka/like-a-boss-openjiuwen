Name: Firm-191
Sector: sensors
Founded: 1967
