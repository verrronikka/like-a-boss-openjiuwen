ID: one
Name: Person-39
Employer: Firm-39
Born: 1932
