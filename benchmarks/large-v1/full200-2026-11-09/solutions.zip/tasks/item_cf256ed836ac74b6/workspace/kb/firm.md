Name: Firm-196
Headquarters: Kyoto
