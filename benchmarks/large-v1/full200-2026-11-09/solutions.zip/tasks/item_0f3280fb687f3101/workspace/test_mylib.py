import unittest
import mylib as m
class Tests(unittest.TestCase):
 def test_contract(self):
  v=m.palindrome('a7777a')
  self.assertIs(type(v),bool)
  self.assertEqual(v,True)
  self.assertEqual(v,True)
  self.assertFalse(m.palindrome('abcd'))
  self.assertTrue(m.palindrome(''))
if __name__=='__main__': unittest.main()
