import unittest
import mylib as m
class Tests(unittest.TestCase):
 def test_contract(self):
  v=m.sorted_copy([28,8,3])
  self.assertIs(type(v),list)
  self.assertEqual(v,[3, 8, 28])
  self.assertEqual(v,[3, 8, 28])
  xs=[28,8,3]
  m.sorted_copy(xs)
  self.assertEqual(xs,[28,8,3])
if __name__=='__main__': unittest.main()
