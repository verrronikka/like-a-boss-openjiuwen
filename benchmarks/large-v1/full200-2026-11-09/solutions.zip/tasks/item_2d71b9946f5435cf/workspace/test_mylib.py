import unittest
import mylib as m
class Tests(unittest.TestCase):
 def test_contract(self):
  v=m.choose()
  self.assertIs(type(v),int)
  self.assertGreater(v,36)
  self.assertLess(v,38)
if __name__=='__main__': unittest.main()
