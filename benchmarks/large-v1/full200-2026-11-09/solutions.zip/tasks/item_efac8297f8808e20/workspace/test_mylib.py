import unittest
import mylib as m
class Tests(unittest.TestCase):
 def test_contract(self):
  v=m.unique([70,8,70,8,8])
  self.assertIs(type(v),list)
  self.assertEqual(v,[70, 8])
  self.assertEqual(v,[70, 8])
if __name__=='__main__': unittest.main()
