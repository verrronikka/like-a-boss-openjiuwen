def unique(xs):
    seen = set()
    result = []
    unhashable = []
    for x in xs:
        try:
            if x not in seen:
                seen.add(x)
                result.append(x)
        except TypeError:
            if not any(x == u for u in unhashable):
                unhashable.append(x)
                result.append(x)
    return result
