import unittest
import mylib as m
class Tests(unittest.TestCase):
 def test_contract(self):
  v=m.transform([61,9])
  self.assertIs(type(v),list)
  self.assertEqual(v,[66, 14])
  self.assertEqual(v,[66, 14, 999])
if __name__=='__main__': unittest.main()
