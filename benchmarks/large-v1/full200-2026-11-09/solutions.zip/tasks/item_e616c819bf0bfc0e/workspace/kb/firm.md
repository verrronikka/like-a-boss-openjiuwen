Name: Firm-82
Sector: sensors
Founded: 1931
