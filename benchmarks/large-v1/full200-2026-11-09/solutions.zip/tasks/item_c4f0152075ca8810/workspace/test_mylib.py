import unittest
import mylib as m
class Tests(unittest.TestCase):
 def test_contract(self):
  v=m.sorted_copy([57,6,2])
  self.assertIs(type(v),list)
  self.assertEqual(v,[2, 6, 57])
  self.assertEqual(v,[2, 6, 57])
  xs=[57,6,2]
  m.sorted_copy(xs)
  self.assertEqual(xs,[57,6,2])
if __name__=='__main__': unittest.main()
