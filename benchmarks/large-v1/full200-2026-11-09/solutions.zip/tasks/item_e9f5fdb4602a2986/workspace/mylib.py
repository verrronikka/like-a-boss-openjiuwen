def transform(xs):
    return [x + 7 if isinstance(x, int) and not isinstance(x, bool) else x for x in xs]
