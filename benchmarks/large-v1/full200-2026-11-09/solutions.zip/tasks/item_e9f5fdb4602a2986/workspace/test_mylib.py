import unittest
import mylib as m
class Tests(unittest.TestCase):
 def test_contract(self):
  v=m.transform([69,5])
  self.assertIs(type(v),list)
  self.assertEqual(v,[76, 12])
  self.assertEqual(v,[76, 12])
if __name__=='__main__': unittest.main()
