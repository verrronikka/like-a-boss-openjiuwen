import unittest
import mylib as m
class Tests(unittest.TestCase):
 def test_contract(self):
  v=m.sorted_copy([74,5,7])
  self.assertIs(type(v),list)
  self.assertEqual(v,[5, 7, 74])
  self.assertEqual(v,[5, 7, 74])
  xs=[74,5,7]
  m.sorted_copy(xs)
  self.assertEqual(xs,[74,5,7])
if __name__=='__main__': unittest.main()
