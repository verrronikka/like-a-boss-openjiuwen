Name: Firm-149
Headquarters: Oslo
