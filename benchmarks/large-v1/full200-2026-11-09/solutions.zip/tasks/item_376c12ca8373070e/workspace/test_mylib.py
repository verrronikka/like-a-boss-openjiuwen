import unittest
import mylib as m
class Tests(unittest.TestCase):
 def test_contract(self):
  v=m.sorted_copy([66,6,5])
  self.assertIs(type(v),list)
  self.assertEqual(v,[5, 6, 66])
  self.assertEqual(v,[5, 6, 66])
  xs=[66,6,5]
  m.sorted_copy(xs)
  self.assertEqual(xs,[66,6,5])
if __name__=='__main__': unittest.main()
