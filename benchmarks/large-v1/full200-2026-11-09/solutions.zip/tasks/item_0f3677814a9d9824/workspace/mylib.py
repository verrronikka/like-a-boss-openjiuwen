def transform(xs):
 return xs
