import unittest
import mylib as m
class Tests(unittest.TestCase):
 def test_contract(self):
  v=m.transform([76,4])
  self.assertIs(type(v),list)
  self.assertEqual(v,[83, 11])
  self.assertEqual(v,[83, 11, 999])
if __name__=='__main__': unittest.main()
