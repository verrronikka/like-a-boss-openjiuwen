Name: Unrelated Firm
Headquarters: Paris
