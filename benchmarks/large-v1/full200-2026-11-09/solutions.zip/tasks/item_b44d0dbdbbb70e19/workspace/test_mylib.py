import unittest
import mylib as m
class Tests(unittest.TestCase):
 def test_contract(self):
  v=m.sorted_copy([25,2,7])
  self.assertIs(type(v),list)
  self.assertEqual(v,[2, 7, 25])
  self.assertEqual(v,[2, 7, 25])
  xs=[25,2,7]
  m.sorted_copy(xs)
  self.assertEqual(xs,[25,2,7])
if __name__=='__main__': unittest.main()
