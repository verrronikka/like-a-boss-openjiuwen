def palindrome(s):
 return False
