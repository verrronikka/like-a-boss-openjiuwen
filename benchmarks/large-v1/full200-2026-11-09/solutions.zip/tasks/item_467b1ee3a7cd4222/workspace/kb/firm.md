Name: Firm-187
Sector: sensors
