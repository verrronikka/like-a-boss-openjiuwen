import unittest
import mylib as m
class Tests(unittest.TestCase):
 def test_contract(self):
  v=m.palindrome('a4444a')
  self.assertIs(type(v),bool)
  self.assertEqual(v,True)
  self.assertEqual(v,False)
if __name__=='__main__': unittest.main()
