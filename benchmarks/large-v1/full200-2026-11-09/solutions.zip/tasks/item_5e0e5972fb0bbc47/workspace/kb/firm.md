Name: Firm-36
Sector: sensors
Founded: 1959
