Name: Firm-24
Sector: sensors
Founded: 1921
