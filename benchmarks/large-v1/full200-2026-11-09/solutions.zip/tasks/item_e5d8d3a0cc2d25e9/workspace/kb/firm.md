Name: Firm-20
Sector: sensors
Founded: 1934
