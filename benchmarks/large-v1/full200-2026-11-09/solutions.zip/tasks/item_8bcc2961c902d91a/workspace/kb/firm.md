Name: Firm-64
Headquarters: Oslo
