Company: Firm-6
Date: 2024-01-01
Headquarters: Rome
