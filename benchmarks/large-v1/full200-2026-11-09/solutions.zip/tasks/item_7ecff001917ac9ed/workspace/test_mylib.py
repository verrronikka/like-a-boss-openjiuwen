import unittest
import mylib as m
class Tests(unittest.TestCase):
 def test_contract(self):
  v=m.unique([59,5,59,2,5])
  self.assertIs(type(v),list)
  self.assertEqual(v,[59, 5, 2])
  self.assertEqual(v,[59, 5, 2])
if __name__=='__main__': unittest.main()
