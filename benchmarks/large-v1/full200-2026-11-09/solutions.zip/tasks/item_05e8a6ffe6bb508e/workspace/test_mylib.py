import unittest
import mylib as m
class Tests(unittest.TestCase):
 def test_contract(self):
  v=m.sorted_copy([35,4,3])
  self.assertIs(type(v),list)
  self.assertEqual(v,[3, 4, 35])
  self.assertEqual(v,[3, 4, 35])
  xs=[35,4,3]
  m.sorted_copy(xs)
  self.assertEqual(xs,[35,4,3])
if __name__=='__main__': unittest.main()
