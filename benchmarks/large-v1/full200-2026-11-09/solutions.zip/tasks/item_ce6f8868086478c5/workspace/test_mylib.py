import unittest
import mylib as m
class Tests(unittest.TestCase):
 def test_contract(self):
  v=m.unique([34,8,34,4,8])
  self.assertIs(type(v),list)
  self.assertEqual(v,[34, 8, 4])
  self.assertEqual(v,[34, 8, 4])
if __name__=='__main__': unittest.main()
