import unittest
import mylib as m
class Tests(unittest.TestCase):
 def test_contract(self):
  v=m.transform([60,6])
  self.assertIs(type(v),list)
  self.assertEqual(v,[62, 8])
  self.assertEqual(v,[62, 8])
if __name__=='__main__': unittest.main()
