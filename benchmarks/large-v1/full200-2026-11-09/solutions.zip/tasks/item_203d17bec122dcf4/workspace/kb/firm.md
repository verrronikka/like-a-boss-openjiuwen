Name: Firm-193
Sector: sensors
Founded: 1957
