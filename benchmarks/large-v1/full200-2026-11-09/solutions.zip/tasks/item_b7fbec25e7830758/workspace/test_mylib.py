import unittest
import mylib as m
class Tests(unittest.TestCase):
 def test_contract(self):
  v=m.unique([42,3,42,4,3])
  self.assertIs(type(v),list)
  self.assertEqual(v,[42, 3, 4])
  self.assertEqual(v,[42, 3, 4, 999])
if __name__=='__main__': unittest.main()
