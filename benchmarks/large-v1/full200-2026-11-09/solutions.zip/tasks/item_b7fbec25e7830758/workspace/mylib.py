def unique(xs):
 return []
