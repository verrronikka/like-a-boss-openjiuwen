import unittest
import mylib as m
class Tests(unittest.TestCase):
 def test_contract(self):
  v=m.unique([43,5,43,4,5])
  self.assertIs(type(v),list)
  self.assertEqual(v,[43, 5, 4])
  self.assertEqual(v,[43, 5, 4])
if __name__=='__main__': unittest.main()
