import unittest
import mylib as m
class Tests(unittest.TestCase):
 def test_contract(self):
  v=m.unique([47,7,47,2,7])
  self.assertIs(type(v),list)
  self.assertEqual(v,[47, 7, 2])
  self.assertEqual(v,[47, 7, 2])
if __name__=='__main__': unittest.main()
