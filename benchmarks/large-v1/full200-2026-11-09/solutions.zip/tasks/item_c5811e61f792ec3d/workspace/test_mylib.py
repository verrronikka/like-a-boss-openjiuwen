import unittest
import mylib as m
class Tests(unittest.TestCase):
 def test_contract(self):
  v=m.unique([32,3,32,4,3])
  self.assertIs(type(v),list)
  self.assertEqual(v,[32, 3, 4])
  self.assertEqual(v,[32, 3, 4])
if __name__=='__main__': unittest.main()
