Name: Firm-41
Sector: sensors
Founded: 1933
