import unittest
import mylib as m
class Tests(unittest.TestCase):
 def test_contract(self):
  v=m.transform([33,8])
  self.assertIs(type(v),list)
  self.assertEqual(v,[39, 14])
  self.assertEqual(v,[39, 14])
if __name__=='__main__': unittest.main()
