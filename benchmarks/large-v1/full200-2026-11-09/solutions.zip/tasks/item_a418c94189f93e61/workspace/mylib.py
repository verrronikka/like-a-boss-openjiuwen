def transform(xs):
    return [x + 7 if isinstance(x, int) else x for x in xs]
