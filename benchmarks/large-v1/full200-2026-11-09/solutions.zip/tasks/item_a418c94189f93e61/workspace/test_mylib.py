import unittest
import mylib as m
class Tests(unittest.TestCase):
 def test_contract(self):
  v=m.transform([23,3])
  self.assertIs(type(v),list)
  self.assertEqual(v,[30, 10])
  self.assertEqual(v,[30, 10])
if __name__=='__main__': unittest.main()
