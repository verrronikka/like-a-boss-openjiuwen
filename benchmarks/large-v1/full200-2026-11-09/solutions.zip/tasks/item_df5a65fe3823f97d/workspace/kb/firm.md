Name: Firm-127
Sector: sensors
Founded: 1929
