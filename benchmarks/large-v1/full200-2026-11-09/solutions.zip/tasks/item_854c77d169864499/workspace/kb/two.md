ID: two
Name: Person-30
Employer: Other
Born: 1923
