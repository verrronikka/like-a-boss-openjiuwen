Company: Firm-145
City: Kyoto
