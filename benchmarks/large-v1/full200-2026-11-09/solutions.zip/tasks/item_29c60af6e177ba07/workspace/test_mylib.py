import unittest
import mylib as m
class Tests(unittest.TestCase):
 def test_contract(self):
  v=m.unique([33,2,33,4,2])
  self.assertIs(type(v),list)
  self.assertEqual(v,[33, 2, 4])
  self.assertEqual(v,[33, 2, 4])
if __name__=='__main__': unittest.main()
