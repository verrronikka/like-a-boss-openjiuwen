import unittest
import mylib as m
class Tests(unittest.TestCase):
 def test_contract(self):
  v=m.sorted_copy([51,7,9])
  self.assertIs(type(v),list)
  self.assertEqual(v,[7, 9, 51])
  self.assertEqual(v,[7, 9, 51])
  xs=[51,7,9]
  m.sorted_copy(xs)
  self.assertEqual(xs,[51,7,9])
if __name__=='__main__': unittest.main()
