Company: Firm-99
Date: 2025-02-01
Headquarters: Kyoto
