def palindrome(s):
    return bool(s == s[::-1])
