def choose(): return 30
