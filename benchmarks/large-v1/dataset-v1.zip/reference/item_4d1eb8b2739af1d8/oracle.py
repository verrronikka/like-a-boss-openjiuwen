def choose(): return 39
