def choose(): return 67
