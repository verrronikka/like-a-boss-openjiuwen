def sorted_copy(xs): return sorted(xs)
