def transform(xs): return [x+7 for x in xs]
