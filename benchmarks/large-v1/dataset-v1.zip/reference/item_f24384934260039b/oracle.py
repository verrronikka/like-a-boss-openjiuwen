def transform(xs): return [x+5 for x in xs]
