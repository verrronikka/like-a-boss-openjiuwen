def choose(): return 56
