def choose(): return 46
