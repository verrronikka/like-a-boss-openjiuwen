def transform(xs): return [x+3 for x in xs]
