def transform(xs): return [x+4 for x in xs]
