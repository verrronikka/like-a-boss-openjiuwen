def transform(xs): return [x+2 for x in xs]
