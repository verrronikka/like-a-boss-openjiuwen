def choose(): return 37
