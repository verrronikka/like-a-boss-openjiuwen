def transform(xs): return [x+6 for x in xs]
